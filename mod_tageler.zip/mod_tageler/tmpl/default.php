<?php

defined('_JEXEC') or die('Restricted access'); // no direct access

foreach ($tageler as $t)
{
    echo $t->einheit."<br />";
}
