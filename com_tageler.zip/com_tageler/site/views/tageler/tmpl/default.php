<?php
// Sicherheitscheck
defined('_JEXEC') or die('Restricted access');

function date_mysql2german($date)
{
    $d    =    explode("-",$date);
    
    return    sprintf("%02d.%02d.%04d", $d[2], $d[1], $d[0]);
}
?>

<h1>Tageler für <?php echo $this->einheit; ?> am <?php echo date_mysql2german($this->tageler->datum); ?></h1>
<table>
    <tr>
        <td>Titel:</td><td><?php echo $this->tageler->titel; ?></td>
    </tr>
    <!--<tr>
        <td>Datum:</td><td><?php echo $this->tageler->datum; ?></td>
    </tr>-->
    <tr>
        <td>Beginn:</td><td><?php echo $this->tageler->beginn; ?></td>
    </tr>
    <tr>
        <td>Schluss:</td><td><?php echo $this->tageler->schluss; ?></td>
    </tr>
    <tr>
        <td>Mitbringen:</td><td><?php echo $this->tageler->mitbringen; ?></td>
    </tr>
    <tr>
        <td>Tenü:</td><td><?php echo $this->tageler->tenue; ?></td>
    </tr>
</table>