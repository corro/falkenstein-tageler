DROP TABLE IF EXISTS `#__tageler`;
